"""MandiGuard package."""
